package com.miniproject.demo.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import com.miniproject.demo.entity.Admin;

public interface AdminRepository extends JpaRepository<Admin,Integer>
{
	@Procedure ("validate")
	List<Admin> validate
	(
		@Param("username") String username,
		@Param("password") String password
	); 
	
	@Procedure ("insert_admin")
	void InsertAdmin
	(
		
		@Param("name") String name,
		@Param("@store_code")int storeCode,
		@Param("username") String username,
		@Param("password") String password
	);
	
	@Procedure ("validate_existing_admin")
	List<Admin> validateExistingAdmin
	(
			@Param("username") String username	
	);
}