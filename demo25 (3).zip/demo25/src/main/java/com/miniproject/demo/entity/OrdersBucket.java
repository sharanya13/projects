package com.miniproject.demo.entity;

import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="orders_bucket")
public class OrdersBucket
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id")
    private int id;
    
    @ManyToOne
    @JoinColumn(name="customer_id")
    private Customers customerId;
    
    @ManyToOne
    @JoinColumn(name = "book_id")
    private Books bookId;
    
    @Column(name="quantity")
    private int quantity;
     @Column(name="price")
    private double price;
     
    @Column(name="created_at")
    private LocalDateTime createdAt;

    public OrdersBucket(){}

	public OrdersBucket(int id, Customers customerId, Books bookId, int quantity, double price,
			LocalDateTime createdAt) {
		this.id = id;
		this.customerId = customerId;
		this.bookId = bookId;
		this.quantity = quantity;
		this.price = price;
		this.createdAt = createdAt;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Customers getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Customers customerId) {
		this.customerId = customerId;
	}

	public Books getBookId() {
		return bookId;
	}

	public void setBookId(Books bookId) {
		this.bookId = bookId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
    
}

 