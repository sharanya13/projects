package com.miniproject.demo.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.miniproject.demo.entity.Customers;
import com.miniproject.demo.repository.CustomersRepository;
import com.miniproject.demo.service. CustomersService;
import com.miniproject.demo.service.SessionService;

@CrossOrigin(origins = {"http://localhost:4200"})
@RequestMapping("/customers")
@RestController
public class CustomersController
{
      @Autowired
      CustomersService customersService;
      
      @Autowired
  	  SessionService sessionService;
      
      @Autowired
      CustomersRepository customersRepository;
      
      @GetMapping(value="/id",produces="application/json")
      public List<Customers> getCustomersDetails()
      {
            List<Customers> clist =  customersService.getCustomersDetails();
            return clist;
      }
      
      
      //Login
      @PostMapping(value="/",consumes="application/json")
      public int validateCustomers(@RequestBody Customers customers)
      {
    	  System.out.println(customers.getPassword());
    	  List<Customers> l = customersService.validateCustomers(customers);
    	  
    	  if(l.size()!=0)
          {
	    	  for(int i=0;i<l.size();i++)
	    	  {
	    		  Customers c = l.get(i);
	    		  int id = c.getCustomerId();
	    		  sessionService.InsertIntoSession(id);
	    	  }
        	  return 1;
          }
          return 0;
      }
      
      //Registration
      @PostMapping(value="/insert",consumes="application/json")
      public int insertCustomers(@RequestBody Customers customers)
      {
    	  
    	if(customersService.validateExistingCustomers(customers)==0)
  		{
  			System.out.println("not existing");
  			System.out.println(customers.getUsername()+" "+customers.getPassword()+" "+customers.getFirstName()+" "+customers.getLastName()+" "+
  			customers.getEmail()+" "+customers.getPhoneNumber()+" "+customers.getAddress());
  			customersRepository.insertCustomers(customers.getUsername(),customers.getPassword(),
            		  customers.getFirstName(),customers.getLastName(),customers.getEmail(),customers.getPhoneNumber(),customers.getAddress());
  			return 1;
  		}
  		return 0;
      }
}