package com.miniproject.demo.entity;

import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="discount")
public class Discount
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="discount_id")
    private int  discountId;
    
    @OneToOne
    @JoinColumn(name="book_id")
    private Books  bookId;
    
    @Column(name="discount_amount")
    private int  discountAmount;
    
    @Column(name="created_at")
    private LocalDateTime  createdAt ;

    public Discount(){}


	public Discount(int discountId, Books bookId, int discountAmount, LocalDateTime createdAt) {
		this.discountId = discountId;
		this.bookId = bookId;
		this.discountAmount = discountAmount;
		this.createdAt = createdAt;
	}

	public int getDiscountId() {
		return discountId;
	}

	public void setDiscountId(int discountId) {
		this.discountId = discountId;
	}

	public Books getBookId() {
		return bookId;
	}


	public void setBookId(Books bookId) {
		this.bookId = bookId;
	}


	public int getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(int discountAmount) {
		this.discountAmount = discountAmount;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
}

 