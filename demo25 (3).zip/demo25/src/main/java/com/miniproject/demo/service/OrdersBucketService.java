package com.miniproject.demo.service;

import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.miniproject.demo.entity.OrdersBucket;
import com.miniproject.demo.repository.OrdersBucketRepository;

@Service
public class OrdersBucketService
{
	@Autowired
	OrdersBucketRepository ordersBucketRepository;
	
	@Transactional(readOnly=true)
	public List<OrdersBucket> getAllOrdersBucket()
	{
		return ordersBucketRepository.getAllOrdersBucket();
	}
	
	@Transactional
	public void insertOrdersBucket(int bookid , int quantity )
	{
		ordersBucketRepository.insertOrdersBucket(bookid,quantity);
	}
	
	@Transactional
	public void updateBucket(int bookid , int quantity )
	{
		ordersBucketRepository.updateBucket(bookid,quantity);
	}
	
	@Transactional
	public void removeItem(int bookid)
	{
		ordersBucketRepository.removeItem(bookid);
	}
	
	@Transactional
	public void searchInCart(String search)
	{
		ordersBucketRepository.searchInCart(search+'%');
	}
	
}

 