package com.miniproject.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.miniproject.demo.entity.Authors;
import com.miniproject.demo.repository.AuthorsRepository;

@Service
public class AuthorsService
{
    @Autowired
    AuthorsRepository authorsRepository;
 
    @Transactional(readOnly=true)
    public List<Authors> getAllAuthors()
    {
        return authorsRepository.findAll();
    }
    
    
    @Transactional
    public void insertAuthors(String authorName,String country,String email,long phoneNumber)
    {
        authorsRepository.insertAuthor( authorName, country, email, phoneNumber);
    }
    
}