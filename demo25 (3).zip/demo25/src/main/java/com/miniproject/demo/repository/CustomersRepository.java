package com.miniproject.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.miniproject.demo.entity.Customers;

public interface CustomersRepository extends JpaRepository<Customers,Integer>
{

	@Procedure("insert_customer")
	void insertCustomers
	(	
		@Param("username") String username,
		@Param("password") String password,
		@Param("first_name") String firstName,
		@Param("last_name") String lastName,
		@Param("email") String email,
		@Param("phone_number") long phoneNumber,
		@Param("address") String address
	);
	
	@Procedure("validate_existing_customer")
	List<Customers> validateExistingCustomer(
	    @Param("username") String username
	);
	
	@Procedure("validate_customer")
	List<Customers> validateCustomers(
	    @Param("username") String username,
	    @Param("password") String password
	);
	
	@Procedure("customer_details")
	List<Customers> getCustomersDetails();
}