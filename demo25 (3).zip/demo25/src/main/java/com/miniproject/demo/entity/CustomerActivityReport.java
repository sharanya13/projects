package com.miniproject.demo.entity;
import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="customer_activity_report")
public class CustomerActivityReport 
{
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id")
    private int id;
    
	@ManyToOne
	@JoinColumn(name="customer_id")
    private Customers customerId;
	
    @Column(name="books_purchased")
    private int booksPurchased;
    
    @Column(name="total_price")
    private double totalPrice;
    
    @Column(name="order_date")
    private LocalDate orderDate;

    @Column(name="created_at")
    private LocalDateTime createdAt;

    public CustomerActivityReport() {}

	public CustomerActivityReport(int id, Customers customerId, int booksPurchased, double totalPrice,
			LocalDate orderDate, LocalDateTime createdAt) {
		this.id = id;
		this.customerId = customerId;
		this.booksPurchased = booksPurchased;
		this.totalPrice = totalPrice;
		this.orderDate = orderDate;
		this.createdAt = createdAt;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Customers getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Customers customerId) {
		this.customerId = customerId;
	}

	public int getBooksPurchased() {
		return booksPurchased;
	}

	public void setBooksPurchased(int booksPurchased) {
		this.booksPurchased = booksPurchased;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
    
    
}
