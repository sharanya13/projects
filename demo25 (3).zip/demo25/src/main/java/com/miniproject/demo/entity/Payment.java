package com.miniproject.demo.entity;

import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table(name="payment")
public class Payment
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="payment_id")
    private int  paymentId;
    
    @ManyToOne
    @JoinColumn(name="customer_id")
    private Customers  customerId;
    
    @Column(name="total_amount")
    private double totalAmount;
    @Column(name="status")
    private String status;
    @Column(name="shipping")
    private double shipping;
    @Column(name="tax")
    private double  tax;
    @Column(name="created_at")
    private LocalDateTime  createdAt ;

    public Payment(){}

	public Payment(int paymentId, Customers customerId, double totalAmount, String status, double shipping, double tax,
			LocalDateTime createdAt) {
		super();
		this.paymentId = paymentId;
		this.customerId = customerId;
		this.totalAmount = totalAmount;
		this.status = status;
		this.shipping = shipping;
		this.tax = tax;
		this.createdAt = createdAt;
	}

	public int getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}

	public Customers getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Customers customerId) {
		this.customerId = customerId;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public double getShipping() {
		return shipping;
	}

	public void setShipping(double shipping) {
		this.shipping = shipping;
	}

	public double getTax() {
		return tax;
	}

	public void setTax(double tax) {
		this.tax = tax;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	
    
}