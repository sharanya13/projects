package com.miniproject.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import com.miniproject.demo.entity.Session;

public interface SessionRepository extends JpaRepository<Session,Integer>
{
	@Procedure ("insert_into_session")
	void InsertIntoSession 
	(
			@Param("customer_id") int customerid
	);
	
	@Procedure("logout")
	void logout();
}
