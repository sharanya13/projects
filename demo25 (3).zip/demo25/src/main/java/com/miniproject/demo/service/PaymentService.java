package com.miniproject.demo.service;

import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.miniproject.demo.entity.Payment;
import com.miniproject.demo.repository.PaymentRepository;

@Service
public class PaymentService
{
	@Autowired
	PaymentRepository paymentRepository;
	
	@Transactional(readOnly=true)
	public List<Payment> getPaymentDeatils()
	{
		return paymentRepository.getPaymentDeatils();
	}
	
	@Transactional
	public void insertPayment(double totalAmount)
	{
		paymentRepository.insertPayment(totalAmount);
	}
	
}

 