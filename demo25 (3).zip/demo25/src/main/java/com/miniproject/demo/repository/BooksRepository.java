package com.miniproject.demo.repository;

import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.miniproject.demo.entity.Books;

public interface BooksRepository extends JpaRepository<Books,Integer>
{
	@Procedure("search_books")
	List<Books> getBookBySearch
	(
		@Param("search") String search 
	);
	
	@Procedure("popular_books")
	List<Books> popularBooks();
	
	@Procedure("insert_book")
	void insertBook
	(
		@Param("author_id") int authorId, 
		@Param("title") String title, 
		@Param("isbn") long isbn ,
		@Param("category") String category,
		@Param("publication_year") LocalDate publicationYear,
		@Param("price") double price
	);
}