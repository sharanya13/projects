package com.miniproject.demo.entity;

import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="inventory")
public class Inventory
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="inventory_id")
    private int inventoryId;
    
    @OneToOne
    @JoinColumn(name="book_id")
    private Books bookId;
    
    @Column(name="stock_level_used")
    private int stockLevelUsed;
    @Column(name="stock_level_left")
    private int stockLevelLeft;
    @Column(name="created_at")
    private LocalDateTime createdAt ;
    
    public Inventory() {}

	public Inventory(int inventoryId, Books bookId, int stockLevelUsed, int stockLevelLeft, LocalDateTime createdAt) {
		this.inventoryId = inventoryId;
		this.bookId = bookId;
		this.stockLevelUsed = stockLevelUsed;
		this.stockLevelLeft = stockLevelLeft;
		this.createdAt = createdAt;
	}

	public int getInventoryId() {
		return inventoryId;
	}

	public void setInventoryId(int inventoryId) {
		this.inventoryId = inventoryId;
	}

	public Books getBookId() {
		return bookId;
	}

	public void setBookId(Books bookId) {
		this.bookId = bookId;
	}

	public int getStockLevelUsed() {
		return stockLevelUsed;
	}

	public void setStockLevelUsed(int stockLevelUsed) {
		this.stockLevelUsed = stockLevelUsed;
	}

	public int getStockLevelLeft() {
		return stockLevelLeft;
	}

	public void setStockLevelLeft(int stockLevelLeft) {
		this.stockLevelLeft = stockLevelLeft;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
}