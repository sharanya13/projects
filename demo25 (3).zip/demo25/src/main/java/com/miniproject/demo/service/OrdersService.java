package com.miniproject.demo.service;

import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.miniproject.demo.entity.Orders;
import com.miniproject.demo.repository.OrdersRepository;

@Service
public class OrdersService
{

    @Autowired
    OrdersRepository ordersRepository;
    
    @Transactional(readOnly=true)
    public List<Orders> getAllOrders()
    {
    	return ordersRepository.findAll();
    }
    
}

