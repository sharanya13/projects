package com.miniproject.demo.entity;

import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="reports")
public class Reports
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="report_id")
    private int  reportId;
    
    @OneToOne
    @JoinColumn(name="book_id")
    private Books bookId;
    
    @Column(name="title")
    private String title;
    @Column(name="stock_level_used")
    private int stockLevelUsed;
    @Column(name="created_at")
    private LocalDateTime createdAt ;

    public Reports(){}

	public Reports(int reportId, Books bookId, String title, int stockLevelUsed, LocalDateTime createdAt) {
		this.reportId = reportId;
		this.bookId = bookId;
		this.title = title;
		this.stockLevelUsed = stockLevelUsed;
		this.createdAt = createdAt;
	}

	public int getReportId() {
		return reportId;
	}

	public void setReportId(int reportId) {
		this.reportId = reportId;
	}

	public Books getBookId() {
		return bookId;
	}

	public void setBookId(Books bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getStockLevelUsed() {
		return stockLevelUsed;
	}

	public void setStockLevelUsed(int stockLevelUsed) {
		this.stockLevelUsed = stockLevelUsed;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	
}

 