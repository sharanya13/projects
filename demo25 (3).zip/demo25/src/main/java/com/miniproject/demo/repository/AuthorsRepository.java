package com.miniproject.demo.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.miniproject.demo.entity.Authors;

public interface AuthorsRepository extends JpaRepository<Authors,Integer>
{
	@Procedure("insert_author")
	void insertAuthor
	(
		@Param("author_name") String authorName,
		@Param("country") String country,
		@Param("email") String email,
		@Param("phone_number") long phoneNumber	
	);
}