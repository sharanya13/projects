package com.miniproject.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.miniproject.demo.service.SessionService;

@CrossOrigin(origins = {"http://localhost:4200"})
@RequestMapping("/session")
@RestController
public class SessionController 
{
	@Autowired
	SessionService sessionService;
	
	@DeleteMapping(value="/")
	public void logout()
	{
		sessionService.logout();
	}
}

