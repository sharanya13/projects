package com.miniproject.demo.service;

import java.time.LocalDate;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.miniproject.demo.entity.Books;
import com.miniproject.demo.repository.BooksRepository;

@Service
public class BooksService
{

    @Autowired
    BooksRepository booksRepository;

    @Transactional(readOnly=true)
    public List<Books> getAllBooks()
    {
    	return booksRepository.findAll();
    }

    @Transactional(readOnly=true)
	public List<Books> getBookBySearch(String search)
	{
    	List<Books> list = booksRepository.getBookBySearch(search+'%');
		return list;
	}
     
    @Transactional(readOnly = true)
    public List<Books> popularBooks()
    {
    	return booksRepository.popularBooks();
    }
    
    
	@Transactional
	public void insertOrModifyBooks(Books books)
	{
		if(booksRepository.save(books)==null)
			System.out.println("not found");
	}

	@Transactional
	public void insertBook(int authorId, String title, long isbn ,String category,LocalDate publicationYear,double price)
	{
		booksRepository.insertBook(authorId, title, isbn , category, publicationYear, price);
	}
}

 