package com.miniproject.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.miniproject.demo.entity.OrdersBucket;
import com.miniproject.demo.service.OrdersBucketService;

@CrossOrigin(origins = {"http://localhost:4200"})
@RequestMapping("/ordersBucket")
@RestController
public class OrdersBucketController
{
      @Autowired
      OrdersBucketService ordersBucketService;
      
      @GetMapping(value="/",produces="application/json")
      public List<OrdersBucket> getAllOrdersBucket()
      {
            List<OrdersBucket> olist =  ordersBucketService.getAllOrdersBucket();
            return olist;
       }
      
      @PostMapping(value="/",consumes="application/json")
      public void insertOrdersBucket(@RequestBody OrdersBucket ordersBucket)
      {
    	  System.out.println(ordersBucket.getBookId().getBookId());
    	  ordersBucketService.insertOrdersBucket(ordersBucket.getBookId().getBookId(),ordersBucket.getQuantity());
      }
      
      @PostMapping(value="/insert",consumes="application/json")
      public void updateBucket(@RequestBody OrdersBucket ordersBucket)
      {
    	  ordersBucketService.updateBucket(ordersBucket.getBookId().getBookId(),ordersBucket.getQuantity());
      }
      
      @DeleteMapping("/{id}")
      public void deleteItem(@PathVariable int id)
      {
    	  ordersBucketService.removeItem(id);
      }
      
      @GetMapping("/{search}")
      public void searchInCart(@PathVariable String search)
      {
    	  ordersBucketService.searchInCart(search);
      }
      
}