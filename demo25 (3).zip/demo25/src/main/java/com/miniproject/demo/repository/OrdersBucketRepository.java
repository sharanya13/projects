package com.miniproject.demo.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import com.miniproject.demo.entity.OrdersBucket;

public interface OrdersBucketRepository extends JpaRepository<OrdersBucket,Integer>
{
	@Procedure("place_order")
	void insertOrdersBucket
	(
		@Param("book_id") int bookid,
		@Param("quantity") int quantity
	);
	
	@Procedure("update_orders_bucket")
	void updateBucket
	(
		@Param("book_id") int bookid,
		@Param("quantity") int quantity
	);
	
	
	@Procedure("remove_item_from_cart")
	void removeItem
	(
		@Param("book_id") int bookid
	);
	
	@Procedure("cart_list")
	List<OrdersBucket> getAllOrdersBucket();
	
	@Procedure("search_in_cart")
	List<OrdersBucket> searchInCart
	(
		@Param("search") String search
	);
}