package com.miniproject.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.miniproject.demo.entity.Authors;
import com.miniproject.demo.service.AuthorsService;

 
@CrossOrigin(origins = {"http://localhost:4200"})
@RequestMapping("/authors")
@RestController
public class AuthorsController
{
      @Autowired
      AuthorsService authorsService;

      @GetMapping(value="/",produces="application/json")
      public List<Authors> getAllAuthors()
      {
            return authorsService.getAllAuthors();
      }
      
      @PostMapping(value="/", consumes="application/json")
      public void insertAuthors(@RequestBody Authors author)
      {
    	  authorsService.insertAuthors(author.getAuthorName(),author.getCountry(),author.getEmail(),author.getPhoneNumber());
      }
}

