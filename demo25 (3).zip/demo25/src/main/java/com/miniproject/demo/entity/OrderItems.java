package com.miniproject.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.time.LocalDateTime;
import jakarta.persistence.Column;

@Entity
@Table(name="order_items")
public class OrderItems
{
    @Id
    @Column(name="order_item_id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int orderItemId ;
    
    @ManyToOne()
    @JoinColumn(name="order_id")
    private Orders orderId ;
    
    @ManyToOne()
    @JoinColumn(name="book_id")
    private Books bookId;
    
    @Column(name="book_price")
    private double  bookPrice;
    
    @Column(name="quantity")
    private int quantity;
    
    @Column(name="created_at")
    private LocalDateTime  createdAt;
    
    public OrderItems() {}

	public OrderItems(int orderItemId, Orders orderId, Books bookId, double bookPrice, int quantity,
			LocalDateTime createdAt) {
		this.orderItemId = orderItemId;
		this.orderId = orderId;
		this.bookId = bookId;
		this.bookPrice = bookPrice;
		this.quantity = quantity;
		this.createdAt = createdAt;
	}

	public int getOrderItemId() {
		return orderItemId;
	}

	public void setOrderItemId(int orderItemId) {
		this.orderItemId = orderItemId;
	}

	public Orders getOrderId() {
		return orderId;
	}

	public void setOrderId(Orders orderId) {
		this.orderId = orderId;
	}

	public Books getBookId() {
		return bookId;
	}

	public void setBookId(Books bookId) {
		this.bookId = bookId;
	}

	public double getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	
	
}