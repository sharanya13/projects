package com.miniproject.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.miniproject.demo.entity.Discount;
import com.miniproject.demo.service.DiscountService;

@CrossOrigin(origins = {"http://localhost:4200"})
@RequestMapping("/discount")
@RestController
public class DiscountController
{
      @Autowired
      DiscountService discountService;
      @GetMapping(value="/",produces="application/json")
      public ResponseEntity<List<Discount>> getAllDiscount()
      {
            List<Discount> dlist =  discountService.getAllDiscount();
            if(dlist.size()!=0)
                return new ResponseEntity<List<Discount>>(dlist,HttpStatus.OK);
            return new ResponseEntity<List<Discount>>(dlist,HttpStatus.NOT_FOUND);
       }
      @GetMapping(value="/{discountId}",produces="application/json")
      public ResponseEntity<Discount> getDiscountByDiscountId(@PathVariable int discountId)
      {
          Discount d = discountService.getDiscountByDiscountId(discountId);
            if(d!=null)
                return new ResponseEntity<Discount>(d,HttpStatus.OK);
            return new ResponseEntity<Discount>(d,HttpStatus.NOT_FOUND);
      }
      @PostMapping(value="/",consumes="application/json")
      public HttpStatus insertDiscount(@RequestBody Discount discount)
      {
         discountService.insertOrModifyDiscount(discount);
              return HttpStatus.OK;
      }
      @PutMapping(consumes="application/json")
      public HttpStatus modifyDiscount(@RequestBody Discount discountId)
      {
         discountService.insertOrModifyDiscount(discountId);
              return HttpStatus.OK;
      }
      @DeleteMapping("/{DiscountId}")
      public HttpStatus deleteDiscount(@PathVariable int DiscountId)
      {
          if(discountService.deleteDiscountByDiscountId(DiscountId))
              return HttpStatus.OK;
          return HttpStatus.NOT_FOUND;
      }
}

 