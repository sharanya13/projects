package com.miniproject.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import com.miniproject.demo.entity.NewStock;
public interface NewStockRepository extends JpaRepository<NewStock,Integer>
{
	@Procedure("modify_stock")
	void modifyNewStock
	(
		@Param("stock") int stock
	);
}