package com.miniproject.demo.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.miniproject.demo.entity.Payment;

public interface PaymentRepository extends JpaRepository<Payment,Integer>
{
	@Procedure("payment_details")
	List<Payment> getPaymentDeatils();
	
	@Procedure("make_payment")
	void insertPayment
	(
		@Param("total_amount")	double totalamount
	);
	
}