package com.miniproject.demo.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.miniproject.demo.entity.CustomerActivityReport;
import com.miniproject.demo.repository.CustomerActivityReportRepository;

@Service
public class CustomerActivityReportService
{
	@Autowired
	CustomerActivityReportRepository customerActivityReportRepository;
	
	@Transactional(readOnly=true)
	public List<CustomerActivityReport> getAllCustomerActivityReport()
    {
		return customerActivityReportRepository.findAll();
    }
    @Transactional(readOnly=true)
    public CustomerActivityReport getCustomerActivityReportByCustomerActivityReportId(int customerActivityReportId)
    {
    	Optional<CustomerActivityReport> ot = customerActivityReportRepository.findById(customerActivityReportId);
    	if(!ot.isPresent())
    		System.out.println("not found");
    	return ot.get();
        // throw new ResourceNotFoundException();
    }
	@Transactional
	public void insertOrModifyCustomerActivityReport(CustomerActivityReport customerActivityReport)
	{
		if(customerActivityReportRepository.save(customerActivityReport)==null)
			System.out.println("not found");
		// throw new ResourceNotModifiedException();
	}
	@Transactional
	public boolean deleteCustomerActivityReportByCustomerActivityReportId(int customerActivityReportId)
	{
		long count =customerActivityReportRepository.count();
		customerActivityReportRepository.deleteById(customerActivityReportId);
		if(count <= customerActivityReportRepository.count())
			System.out.println("not found");
		return true;
		// throw new ResourceNotFoundException();
	}
}

 