package com.miniproject.demo.entity;

import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="new_stock")
public class NewStock
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="stock_id")
    private int stockid;
    
    @ManyToOne
    @JoinColumn(name="admin_id")
    private Admin adminid;
    
    @ManyToOne
    @JoinColumn(name="book_id")
    private Books bookid;
    
    @Column(name="stock")
    private int stock;
    @Column(name="created_at")
    private LocalDateTime  createdat ;
    
    public NewStock() {}

	public NewStock(int stockid, Admin adminid, Books bookid, int stock, LocalDateTime createdat) {
		this.stockid = stockid;
		this.adminid = adminid;
		this.bookid = bookid;
		this.stock = stock;
		this.createdat = createdat;
	}

	public int getStockid() {
		return stockid;
	}

	public void setStockid(int stockid) {
		this.stockid = stockid;
	}

	public Admin getAdminid() {
		return adminid;
	}

	public void setAdminid(Admin adminid) {
		this.adminid = adminid;
	}

	public Books getBookid() {
		return bookid;
	}

	public void setBookid(Books bookid) {
		this.bookid = bookid;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public LocalDateTime getCreatedat() {
		return createdat;
	}

	public void setCreatedat(LocalDateTime createdat) {
		this.createdat = createdat;
	}
}

