package com.miniproject.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.miniproject.demo.entity.CustomerActivityReport;

public interface CustomerActivityReportRepository extends JpaRepository<CustomerActivityReport,Integer>
{

}

