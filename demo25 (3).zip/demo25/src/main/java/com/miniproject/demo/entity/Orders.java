package com.miniproject.demo.entity;

import java.util.Date;
import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
@Entity
@Table(name="orders")
public class Orders
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="order_id")
    private int orderId;
    
    @ManyToOne
    @JoinColumn(name="customer_id")
    private Customers customerId;
    
    @OneToOne()
    @JoinColumn(name="payment_id")
    private Payment paymentId ;
    
    @Column(name="ordered_date")
    private Date  orderedDate ;
    @Column(name="arrival_date")
    private Date  arrivalDate ;
    @Column(name="created_at")
    private LocalDateTime createdAt ;
    
    public Orders() {}
    
	public Orders(int orderId, Customers customerId, Payment paymentId, Date orderedDate, Date arrivalDate,
			LocalDateTime createdAt) {
		this.orderId = orderId;
		this.customerId = customerId;
		this.paymentId = paymentId;
		this.orderedDate = orderedDate;
		this.arrivalDate = arrivalDate;
		this.createdAt = createdAt;
	}

	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public Customers getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Customers customerId) {
		this.customerId = customerId;
	}

	public Payment getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(Payment paymentId) {
		this.paymentId = paymentId;
	}
	public Date getOrderedDate() {
		return orderedDate;
	}
	public void setOrderedDate(Date orderedDate) {
		this.orderedDate = orderedDate;
	}
	public Date getArrivalDate() {
		return arrivalDate;
	}
	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
    
}