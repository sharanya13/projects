package com.miniproject.demo.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.miniproject.demo.repository.ReportsRepository;
@Service
public class ReportsService
{
	@Autowired
	ReportsRepository reportsRepository;
	
}