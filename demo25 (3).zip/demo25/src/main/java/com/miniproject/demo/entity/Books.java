package com.miniproject.demo.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="books")
public class Books
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="book_id")
    private int bookId;
    
    @Column(name="urls")
    private String urls;
    
    @ManyToOne
    @JoinColumn(name = "author_id")
    private Authors authorId;
   
    @Column(name="title")
    private String title;

    @Column(name="isbn")
    private long isbn;
 
    @Column(name="category")
    private String category;

    @Column(name="publication_year")
    private LocalDate publicationYear;
 
    @Column(name="price")
    private double price;
    
    @Column(name="discount")
    private int discount;
    
    @Column(name="created_at")
    private LocalDateTime createdAt;

    public Books() {}

	public Books(int bookId, String urls, Authors authorId, String title, long isbn, String category,
			LocalDate publicationYear, double price, int discount, LocalDateTime createdAt) {
		this.bookId = bookId;
		this.urls = urls;
		this.authorId = authorId;
		this.title = title;
		this.isbn = isbn;
		this.category = category;
		this.publicationYear = publicationYear;
		this.price = price;
		this.discount = discount;
		this.createdAt = createdAt;
	}



	public int getDiscount() {
		return discount;  
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public Authors getAuthorId() {
		return authorId;
	}

	public void setAuthorId(Authors authorId) {
		this.authorId = authorId;
	}

	public LocalDate getPublicationYear() {
		return publicationYear;
	}

	public void setPublicationYear(LocalDate publicationYear) {
		this.publicationYear = publicationYear;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public long getIsbn() {
		return isbn;
	}

	public void setIsbn(long isbn) {
		this.isbn = isbn;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	public String getUrls() {
		return urls;
	}

	public void setUrls(String urls) {
		this.urls = urls;
	}
    
}