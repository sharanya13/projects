package com.miniproject.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.miniproject.demo.repository.SessionRepository;

@Service
public class SessionService 
{
	@Autowired
	SessionRepository sessionRepository;
	
	@Transactional
	public void InsertIntoSession(int customerid)
	{
		sessionRepository.InsertIntoSession(customerid);
	}
	
	@Transactional
	public void logout()
	{
		sessionRepository.logout();
	}
}
