package com.miniproject.demo.entity;

import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="authors")
public class Authors
{
   @Id
   @GeneratedValue(strategy=GenerationType.IDENTITY)
   @Column(name="author_id")
   private int authorId;
   
   @Column(name="author_name")
   private String authorName;
   
   @Column(name="country")
   private String country;
   
   @Column(name="email")
   private String email;
   
   @Column(name="phone_number")
   private long phoneNumber;
   
   @Column(name="created_at")
   private LocalDateTime createdAt;
   
   public Authors() {}
	
   public Authors(int authorId, String authorName, String country, String email, long phoneNumber,
			LocalDateTime createdAt) {
		this.authorId = authorId;
		this.authorName = authorName;
		this.country = country;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.createdAt = createdAt;
   }

	public int getAuthorId() {
		return authorId;
	}
	
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	
	public String getAuthorName() {
		return authorName;
	}
	
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	
	public String getCountry() {
		return country;
	}
	
	public void setCountry(String country) {
		this.country = country;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public long getPhoneNumber() {
		return phoneNumber;
	}
	
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
}

 